const store = require("./app/store");
const {
    fetchRelatedVideos,
} = require("./features/video/fetchRelatedVideoSlice");

const { fetchVideos } = require("./features/video/fetchVideoSlice");

// store.dispatch(fetchVideos());

async function finalResult() {
    const result = await store.dispatch(fetchVideos());
    const tags = result.payload.tags;
    await store.dispatch(fetchRelatedVideos(tags));
}

finalResult();
