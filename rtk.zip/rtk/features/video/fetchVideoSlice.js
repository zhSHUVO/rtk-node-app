const { createAsyncThunk, createSlice } = require("@reduxjs/toolkit");

// initial state
const initialState = {
    loading: false,
    video: [],
    error: "",
};

// create async thunk
const fetchVideos = createAsyncThunk("video/fetchVideos", async () => {
    const res = await fetch("http://localhost:9000/videos");
    const videos = await res.json();
    return videos;
});

// create slice
const videoSlice = createSlice({
    name: "video",
    initialState,
    extraReducers: (builder) => {
        builder.addCase(fetchVideos.pending, (state, action) => {
            state.loading = true;
            state.error = "";
        });

        builder.addCase(fetchVideos.fulfilled, (state, action) => {
            state.loading = false;
            state.video = action.payload;
            state.error = "";
        });

        builder.addCase(fetchVideos.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});

module.exports = videoSlice.reducer;
module.exports.fetchVideos = fetchVideos;
