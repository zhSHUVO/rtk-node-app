const { createAsyncThunk, createSlice } = require("@reduxjs/toolkit");

// initial state
const initialState = {
    loading: false,
    videos: [],
    error: "",
};

// create async thunk
const fetchRelatedVideos = createAsyncThunk(
    "video/fetchRelatedVideos",
    async (tags) => {
        const queryString = tags.map((tag) => `tags_like=${tag}`).join("&");
        const res = await fetch(`http://localhost:9000/videos?${queryString}`);
        const relatedVideos = await res.json();
        console.log(`http://localhost:9000/videos?${queryString}`);
        return relatedVideos;
    }
);

// create slice
const relatedVideoSlice = createSlice({
    name: "video",
    initialState,
    extraReducers: (builder) => {
        builder.addCase(fetchRelatedVideos.pending, (state, action) => {
            state.loading = true;
            state.error = "";
        });

        builder.addCase(fetchRelatedVideos.fulfilled, (state, action) => {
            state.loading = false;
            state.videos = action.payload.sort((a, b) => {
                if (b.views < a.views) {
                    return -1;
                }
            });
            state.error = "";
        });

        builder.addCase(fetchRelatedVideos.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});

module.exports = relatedVideoSlice.reducer;
module.exports.fetchRelatedVideos = fetchRelatedVideos;
